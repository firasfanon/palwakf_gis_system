import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // المحتوى فقط — الهيدر/الفوتر عبر ShellRoute.
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'حول — مستكشف الوقف',
          textDirection: TextDirection.rtl,
        ),
      ),
    );
  }
}
