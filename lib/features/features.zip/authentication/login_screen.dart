// lib/features/authentication/login_screen.dart
// استبدل الـ imports والـ demo users

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../admin/domain/user_account.dart';
import '../admin/domain/permissions.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _loading = false;

  // Demo users - غير const لأن UserAccount و Permission ليسوا const
  final List<UserAccount> _demoUsers = [
    UserAccount(
      id: 'demo_super',
      email: 'super@waqf.ps',
      role: UserRole.superuser,
      permissions: Permission.values,
    ),
    UserAccount(
      id: 'demo_admin',
      email: 'admin@waqf.ps',
      role: UserRole.admin,
      permissions: const [
        Permission.manageUsers,
        Permission.manageHome,
        Permission.manageSite,
        Permission.manageMapLayers,
        Permission.manageLandsCrud,
        Permission.viewReports,
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _emailCtrl,
              decoration: const InputDecoration(
                labelText: 'البريد الإلكتروني',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passCtrl,
              decoration: const InputDecoration(
                labelText: 'كلمة المرور',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 24),
            if (_loading)
              const CircularProgressIndicator()
            else
              ElevatedButton(
                onPressed: _handleLogin,
                child: const Text('دخول'),
              ),
            const SizedBox(height: 16),
            const Text(
              'للتجربة:\nsuper@waqf.ps / admin@waqf.ps\nكلمة المرور: أي شيء',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleLogin() async {
    setState(() => _loading = true);

    try {
      // محاولة تسجيل الدخول الفعلي مع Supabase
      await Supabase.instance.client.auth.signInWithPassword(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text.trim(),
      );

      if (mounted) {
        context.go('/admin');
      }
    } catch (e) {
      // في حالة الفشل، استخدم demo users
      final email = _emailCtrl.text.trim();
      final demoUser = _demoUsers.where((u) => u.email == email).firstOrNull;

      if (demoUser != null && mounted) {
        // حفظ معلومات المستخدم Demo
        context.go('/admin');
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('خطأ في تسجيل الدخول')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }
}