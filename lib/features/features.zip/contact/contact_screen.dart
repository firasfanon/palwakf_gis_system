import 'package:flutter/material.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'تواصل معنا — قريباً',
          textDirection: TextDirection.rtl,
        ),
      ),
    );
  }
}
