// lib/features/admin/users/presentation/admin_users_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/user_account.dart';
import '../../domain/permissions.dart';
import 'users_controller.dart';

class AdminUsersScreen extends ConsumerWidget {
  const AdminUsersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usersAsync = ref.watch(usersControllerProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('إدارة المستخدمين')),
      body: usersAsync.when(
        data: (users) => ListView.builder(
          itemCount: users.length,
          itemBuilder: (_, i) {
            final u = users[i];
            final permsTxt = u.role == UserRole.superuser
                ? 'جميع الصلاحيات'
                : u.permissions.map((p) => p.displayName).join('، ');
            return ListTile(
              title: Text(u.email),
              subtitle: Text('${_roleLabel(u.role)} - $permsTxt'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => _openUserDialog(context, ref, u),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      await ref.read(usersControllerProvider.notifier).delete(u.id);
                    },
                  ),
                ],
              ),
            );
          },
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openUserDialog(context, ref),
        child: const Icon(Icons.add),
      ),
    );
  }

  String _roleLabel(UserRole r) {
    switch (r) {
      case UserRole.superuser: return 'سوبر يوزر';
      case UserRole.admin:     return 'مسؤول';
      case UserRole.user:      return 'مستخدم';
      case UserRole.viewer:    return 'عارض';
    }
  }

  Future<void> _openUserDialog(BuildContext context, WidgetRef ref, [UserAccount? u]) async {
    final idCtrl = TextEditingController(text: u?.id);
    final emailCtrl = TextEditingController(text: u?.email);
    final nameCtrl = TextEditingController(text: u?.fullName);
    UserRole role = u?.role ?? UserRole.user;
    final sel = <Permission>{...?(u?.permissions.toSet())};

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: Text(u == null ? 'إضافة مستخدم' : 'تعديل مستخدم'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: idCtrl,
                  decoration: const InputDecoration(labelText: 'معرّف المستخدم'),
                  enabled: u == null,
                ),
                TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
                TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'الاسم الكامل')),
                const SizedBox(height: 16),
                DropdownButtonFormField<UserRole>(
                  value: role,
                  decoration: const InputDecoration(labelText: 'الدور'),
                  items: UserRole.values.map((e) => DropdownMenuItem(value: e, child: Text(_roleText(e)))).toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() {
                        role = v;
                        if (v == UserRole.superuser) {
                          sel.clear();
                          sel.addAll(Permission.values);
                        }
                      });
                    }
                  },
                ),
                const SizedBox(height: 16),
                const Text('الصلاحيات:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: Permission.values.map((p) {
                  final disabled = role == UserRole.superuser;
                  return FilterChip(
                    label: Text(p.displayName),
                    selected: sel.contains(p),
                    onSelected: disabled ? null : (v) {
                      setState(() {
                        if (v) {
                          sel.add(p);
                        } else {
                          sel.remove(p);
                        }
                      });
                    },
                  );
                }).toList()),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            TextButton(
              onPressed: () async {
                Navigator.pop(ctx);
                final perms = role == UserRole.superuser ? Permission.values.toList() : sel.toList();
                final item = UserAccount(
                  id: idCtrl.text.trim(),
                  email: emailCtrl.text.trim(),
                  fullName: nameCtrl.text.trim().isEmpty ? null : nameCtrl.text.trim(),
                  role: role,
                  permissions: perms,
                );
                if (u == null) {
                  await ref.read(usersControllerProvider.notifier).create(item);
                } else {
                  await ref.read(usersControllerProvider.notifier).updateUser(item);
                }
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  static String _roleText(UserRole r) {
    switch (r) {
      case UserRole.superuser: return 'سوبر يوزر (كافة الصلاحيات)';
      case UserRole.admin:     return 'مسؤول';
      case UserRole.user:      return 'مستخدم';
      case UserRole.viewer:    return 'عارض';
    }
  }
}