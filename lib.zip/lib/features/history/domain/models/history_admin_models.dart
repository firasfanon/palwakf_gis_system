// lib/features/history/domain/models/history_admin_models.dart

/// مستوى إداري تاريخي (لواء / قضاء / محافظة / مدينة / قرية / ...).
enum HistoricalAdminLevel {
  liwa,
  qada,
  muhafaza,
  nahiya,
  city,
  village,
  hamlet,
  quarter,
  camp,
}

/// تحويل المستوى الإداري إلى قيمة نصية تُخزَّن في قاعدة البيانات.
String historicalAdminLevelToDb(HistoricalAdminLevel level) {
  switch (level) {
    case HistoricalAdminLevel.liwa:
      return 'liwa';
    case HistoricalAdminLevel.qada:
      return 'qada';
    case HistoricalAdminLevel.muhafaza:
      return 'muhafaza';
    case HistoricalAdminLevel.nahiya:
      return 'nahiya';
    case HistoricalAdminLevel.city:
      return 'city';
    case HistoricalAdminLevel.village:
      return 'village';
    case HistoricalAdminLevel.hamlet:
      return 'hamlet';
    case HistoricalAdminLevel.quarter:
      return 'quarter';
    case HistoricalAdminLevel.camp:
      return 'camp';
  }
}

/// تحويل النص القادم من قاعدة البيانات إلى enum.
HistoricalAdminLevel historicalAdminLevelFromDb(String value) {
  switch (value) {
    case 'liwa':
      return HistoricalAdminLevel.liwa;
    case 'qada':
      return HistoricalAdminLevel.qada;
    case 'muhafaza':
      return HistoricalAdminLevel.muhafaza;
    case 'nahiya':
      return HistoricalAdminLevel.nahiya;
    case 'city':
      return HistoricalAdminLevel.city;
    case 'village':
      return HistoricalAdminLevel.village;
    case 'hamlet':
      return HistoricalAdminLevel.hamlet;
    case 'quarter':
      return HistoricalAdminLevel.quarter;
    case 'camp':
      return HistoricalAdminLevel.camp;
    default:
      return HistoricalAdminLevel.city;
  }
}

/// وحدة إدارية تاريخية (لواء / قضاء / محافظة / مدينة / قرية ...).
class HistoricalAdminUnit {
  final int id;
  final int periodId;
  final HistoricalAdminLevel level;
  final String nameAr;
  final String? nameEn;
  final int? parentId;
  final double? areaKm2;
  final int? population;

  const HistoricalAdminUnit({
    required this.id,
    required this.periodId,
    required this.level,
    required this.nameAr,
    this.nameEn,
    this.parentId,
    this.areaKm2,
    this.population, required code, required metadata, required createdAt, required updatedAt, required altNames,
  });

  HistoricalAdminUnit copyWith({
    int? id,
    int? periodId,
    HistoricalAdminLevel? level,
    String? nameAr,
    String? nameEn,
    int? parentId,
    double? areaKm2,
    int? population, String? code,
  }) {
    return HistoricalAdminUnit(
      id: id ?? this.id,
      periodId: periodId ?? this.periodId,
      level: level ?? this.level,
      nameAr: nameAr ?? this.nameAr,
      nameEn: nameEn ?? this.nameEn,
      parentId: parentId ?? this.parentId,
      areaKm2: areaKm2 ?? this.areaKm2,
      population: population ?? this.population, code: null, metadata: null, createdAt: null, updatedAt: null, altNames: null,
    );
  }

  factory HistoricalAdminUnit.fromJson(Map<String, dynamic> json) {
    return HistoricalAdminUnit(
      id: json['id'] is int ? json['id'] as int : int.parse(json['id'].toString()),
      periodId: json['period_id'] is int
          ? json['period_id'] as int
          : int.parse(json['period_id'].toString()),
      level: historicalAdminLevelFromDb(json['level'] as String),
      nameAr: json['name_ar'] as String,
      nameEn: json['name_en'] as String?,
      parentId: json['parent_id'] == null
          ? null
          : (json['parent_id'] is int
          ? json['parent_id'] as int
          : int.parse(json['parent_id'].toString())),
      areaKm2: json['area_km2'] == null
          ? null
          : (json['area_km2'] is num
          ? (json['area_km2'] as num).toDouble()
          : double.parse(json['area_km2'].toString())),
      population: json['population'] == null
          ? null
          : (json['population'] is int
          ? json['population'] as int
          : int.parse(json['population'].toString())), code: null, metadata: null, createdAt: null, updatedAt: null, altNames: null,
    );
  }

  get code => null;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'period_id': periodId,
      'level': historicalAdminLevelToDb(level),
      'name_ar': nameAr,
      'name_en': nameEn,
      'parent_id': parentId,
      'area_km2': areaKm2,
      'population': population,
    };
  }
}

/// ارتباط أرض بوحدة إدارية تاريخية (تاريخيًا هذه الأرض تبعت لقرية/لواء/قضاء...).
class LandAdminHistoryEntry {
  final int id;
  final int landId;
  final int periodId;
  final int adminUnitId;
  final String? notes;

  const LandAdminHistoryEntry({
    required this.id,
    required this.landId,
    required this.periodId,
    required this.adminUnitId,
    this.notes,
  });

  LandAdminHistoryEntry copyWith({
    int? id,
    int? landId,
    int? periodId,
    int? adminUnitId,
    String? notes,
  }) {
    return LandAdminHistoryEntry(
      id: id ?? this.id,
      landId: landId ?? this.landId,
      periodId: periodId ?? this.periodId,
      adminUnitId: adminUnitId ?? this.adminUnitId,
      notes: notes ?? this.notes,
    );
  }

  factory LandAdminHistoryEntry.fromJson(Map<String, dynamic> json) {
    return LandAdminHistoryEntry(
      id: json['id'] is int ? json['id'] as int : int.parse(json['id'].toString()),
      landId: json['land_id'] is int
          ? json['land_id'] as int
          : int.parse(json['land_id'].toString()),
      periodId: json['period_id'] is int
          ? json['period_id'] as int
          : int.parse(json['period_id'].toString()),
      adminUnitId: json['admin_unit_id'] is int
          ? json['admin_unit_id'] as int
          : int.parse(json['admin_unit_id'].toString()),
      notes: json['notes'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'land_id': landId,
      'period_id': periodId,
      'admin_unit_id': adminUnitId,
      'notes': notes,
    };
  }
}
